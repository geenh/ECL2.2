﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using MinecraftLaunch.Modules.Toolkits;
using ECL2._2.Content;
using ECL2._2.Content.UserPages;

namespace ECL2._2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Content.Download Download = new Content.Download();
        Content.GameStart GameStart = new Content.GameStart();
        Content.Setting Setting = new Content.Setting();
        Content.SettingPages.JavaSetting JavaSetting = new Content.SettingPages.JavaSetting();
       Content.UserPages.Lixian Lixian=new Content.UserPages.Lixian();
        
        public System.Guid clientToken;
        public string rootPath = ".minecraft";
        public static void WriteFile(string Path, string Strings)
        {
            if (!System.IO.File.Exists(Path))
            {
                //Directory.CreateDirectory(Path);
                System.IO.FileStream f = System.IO.File.Create(Path);
                f.Close();
                f.Dispose();
            }
            System.IO.StreamWriter f2 = new System.IO.StreamWriter(Path, true, System.Text.Encoding.UTF8);
            f2.WriteLine(Strings);
            f2.Close();
            f2.Dispose();
        }
        public void Invoke_Data()
        {


            
            if (Directory.Exists("ECL2.2_Datas"))
            {

            }
            else
            {
                DirectoryInfo directoryInfo = new DirectoryInfo("ECL2.2_Datas");
                directoryInfo.Create();
            }

            //if (Directory.Exists("C:\\Users\\Public\\ECL2.2_Temp_Data"))
            //{

            //}
            //else
            //{
            //    DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Users\\Public\\ECL2.2_Temp_Data");
            //    directoryInfo.Create();
            //}
            if (!File.Exists("ECL2.2_Datas\\JavaCombo_Data.txt"))
            {

                FileStream fs = File.Create(@"ECL2.2_Datas\JavaCombo_Data.txt");//创建文件
                fs.Close();
                return;

            }
            if (!File.Exists("ECL2.2_Datas\\Width_Data.txt"))
            {

                WriteFile("ECL2.2_Datas\\Width_Data.txt", "854");

                return;
            }
            if (!File.Exists("ECL2.2_Datas\\Height_Data.txt"))
            {

                WriteFile("ECL2.2_Datas\\Height_Data.txt", "480");
                return;
            }
            if (!File.Exists("ECL2.2_Datas\\MinMemoryTextbox_Data.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\MinMemoryTextbox_Data.txt");//创建文件
                fs.Close();
                return;
            }
            if (!File.Exists("ECL2.2_Datas\\MaxMemoryTextbox_Data.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\MaxMemoryTextbox_Data.txt");//创建文件
                fs.Close();
                return;
            }
            if (!File.Exists("ECL2.2_Datas\\ID_Data.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\ID_Data.txt");//创建文件
                fs.Close();
                return;

            }
            if (!File.Exists("ECL2.2_Datas\\DownloadVersion-Temp.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\DownloadVersion-Temp.txt");//创建文件
                fs.Close();
                return;

            }
            if (!File.Exists("ECL2.2_Datas\\ClientToken_Data.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\ClientToken_Data.txt");//创建文件
                fs.Close();
                return;
            }
            if (!File.Exists("ECL2.2_Datas\\MicrosoftUser_UUID.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\MicrosoftUser_UUID.txt");//创建文件
                fs.Close();
                return;
            }
            

            //if (!File.Exists("C:\\Users\\Public\\ECL2.2_Temp_Data\\UserInfo_Temp.txt"))
            //{

            //    FileStream fs = File.Create("C:\\Users\\Public\\ECL2.2_Temp_Data\\UserInfo_Temp.txt");//创建文件
            //    fs.Close();
            //    return;
            //}
            //Setting.javaCombo.ItemsSource = System.IO.File.ReadAllText("C:\\ECL2_Datas\\JavaCombo_Data.txt");
            JavaSetting.MinMemoryTextbox.Text = System.IO.File.ReadAllText("ECL2.2_Datas\\MinMemoryTextbox_Data.txt");
            JavaSetting.MaxMemoryTextbox.Text = System.IO.File.ReadAllText("ECL2.2_Datas\\MaxMemoryTextbox_Data.txt");
            Lixian.IdTextbox.Text = System.IO.File.ReadAllText("ECL2.2_Datas\\ID_Data.txt");
            JavaSetting.Width1.Text= System.IO.File.ReadAllText("ECL2.2_Datas\\Width_Data.txt");
            JavaSetting.Height.Text = System.IO.File.ReadAllText("ECL2.2_Datas\\Height_Data.txt");

        }
        public MainWindow()
        {
            InitializeComponent();
            try
            {
                string path = "ECL2.2_Datas\\MicrosoftUser_UUID.txt";
                File.Delete(path);
            }
            catch { }
            //try
            //{
            //    string path = "C:\\Users\\Public\\ECL2.2_Temp_Data\\UserInfo_Temp.txt";
            //    File.Delete(path);
            //}
            //catch { }
            Invoke_Data();
           
            if (System.IO.File.ReadAllText("ECL2.2_Datas\\ClientToken_Data.txt") == "")
            {
                var id = Guid.NewGuid().ToString();
                string path = "ECL2.2_Datas\\ClientToken_Data.txt";
                File.Delete(path);
                WriteFile("ECL2.2_Datas\\ClientToken_Data.txt", id);
                clientToken = Guid.Parse(id);
            }



            //foreach (var game in gameList)
            //    {
            //    GameStart.versionCombo.Items.Add(game);

            //}
            //GameStart.versionCombo.Items.Add(core.VersionLocator.GetAllGames().ToList());
            GameStart.versionCombo.Items.Clear();
            GameCoreToolkit toolkit = new(".minecraft");
            var gameList = toolkit.GetGameCores();
            foreach (var game in gameList)
            {
                GameStart.versionCombo.Items.Add(game);

            }
          

            if (GameStart.versionCombo.Items.Count != 0)
            {
                GameStart.versionCombo.SelectedItem = GameStart.versionCombo.Items[0];
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string path = "ECL2.2_Datas\\MicrosoftUser_UUID.txt";
                File.Delete(path);
            }
            catch { }
            //try
            //{
            //    string path = "C:\\Users\\Public\\ECL2.2_Temp_Data\\UserInfo_Temp.txt";
            //    File.Delete(path);
            //}
            //catch { }
            this.Close();
        }



        private async void ListBoxItem_Selected(object sender, RoutedEventArgs e)
        {
            ContentControl1.Content = new Frame
            {
                Content = GameStart
            };

            GameStart.versionCombo.Items.Clear();
            GameCoreToolkit toolkit = new(".minecraft");
            var gameList = toolkit.GetGameCores();
            foreach (var game in gameList)
            {
                GameStart.versionCombo.Items.Add(game);

            }


            if (GameStart.versionCombo.Items.Count != 0)
            {
                GameStart.versionCombo.SelectedItem = GameStart.versionCombo.Items[0];
            }
            for (double i = 0; i < 1; i += 0.05)
            {

                GameStart.GameStart_Page.Opacity = i;
                await Task.Delay(1);
            }
        }

        private async void ListBoxItem_Selected_1(object sender, RoutedEventArgs e)
        {
            ContentControl1.Content = new Frame
            {
                
            };
            //for (double i = 0; i < 1; i += 0.01)
            //{

            //    Download.Download_Page.Opacity = i;
            //    await Task.Delay(1);
            //}
        }

        private async void ListBoxItem_Selected_2(object sender, RoutedEventArgs e)
        {
            ContentControl1.Content = new Frame
            {
                Content = Download
            };
            for (double i = 0; i < 1; i+=0.05)
            {
                
                Download.Download_Page.Opacity =i ;
                await Task.Delay(1);
            }
        }

        private async void ListBoxItem_Selected_3(object sender, RoutedEventArgs e)
        {
            ContentControl1.Content = new Frame
            {
                Content = Setting
            };
            for (double i = 0; i < 1; i += 0.05)
            {

                Setting.Setting_Page.Opacity = i;
                await Task.Delay(1);
            }
        }
    }
}
