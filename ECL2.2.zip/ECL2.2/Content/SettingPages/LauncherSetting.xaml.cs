﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using UpdateD;
using System.Runtime.ConstrainedExecution;
using System.Reflection.Emit;

namespace ECL2._2.Content.SettingPages
{
    /// <summary>
    /// LauncherSetting.xaml 的交互逻辑
    /// </summary>
    public partial class LauncherSetting : Page
    {
        UpdateD.Update updated = new UpdateD.Update();
        public LauncherSetting()
        {
            InitializeComponent();
            
            if (!File.Exists("ECL2.2_Datas\\ClientToken_Data.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\ClientToken_Data.txt");//创建文件
                fs.Close();
                return;
            }
            if (!File.Exists("ECL2.2_Datas\\ClientToken_Data.txt"))
            {
                TextBox1.IsEnabled = false;
                
            }
            else
            {
                TextBox1.IsEnabled = true;
                TextBox1.Text = System.IO.File.ReadAllText("ECL2.2_Datas\\ClientToken_Data.txt");
                TextBox1.IsEnabled = false;
            }
            
        }
        public async Task DongHua1()
        {
            for (int i = 0; i < 80; i++)
            {

                var Mov = OldVersion.Margin;
                Mov.Left -= 5.5;
                OldVersion.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 80; i++)
            {

                var Mov = OldVersion.Margin;
                Mov.Left += 5.5;
                OldVersion.Margin = Mov;
                await Task.Delay(1);


            }

        }
        public async Task DongHua2()
        {
            for (int i = 0; i < 80; i++)
            {

                var Mov = NewVersion.Margin;
                Mov.Left -= 6.4;
                NewVersion.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 80; i++)
            {

                var Mov = NewVersion.Margin;
                Mov.Left += 6.4;
                NewVersion.Margin = Mov;
                await Task.Delay(1);


            }
        }
        public async Task DongHua3()
        {
            for (int i = 0; i < 90; i++)
            {

                var Mov =UPdateText.Margin;
                Mov.Left -= 6.9;
                UPdateText.Margin = Mov;
                //var Mov1 = Label1.Margin;
                //Mov1.Left -= 6.9;
                //Label1.Margin = Mov1;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 90; i++)
            {

                var Mov = UPdateText.Margin;
                Mov.Left +=6.9;
                UPdateText.Margin = Mov;
                //var Mov1 = Label1.Margin;
                //Mov1.Left += 6.9;
                //Label1.Margin = Mov1;
                await Task.Delay(1);


            }

        }


        private async void Button_Click(object sender, RoutedEventArgs e)
        {

            if (updated.GetUpdate("d0068f1fc8b84add9824dc8c3ddcaa4c", "0.0.23") == false)
            {
                Button1.IsEnabled=false;
                await DongHua2();
                Button1.IsEnabled = false;

            }
            else if(updated.GetUpdate("d0068f1fc8b84add9824dc8c3ddcaa4c", "0.0.23") == true)
            {
                Button1.IsEnabled = false;
                await DongHua1();
                Button1.IsEnabled = true;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            TextBox1.IsEnabled = false;
            TextBox1.Text = System.IO.File.ReadAllText("ECL2.2_Datas\\ClientToken_Data.txt");
            
            TextBox1.IsEnabled = true;
        }

        private async void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var i = updated.GetUpdateRem("d0068f1fc8b84add9824dc8c3ddcaa4c");
            UPdateText.IsEnabled = false;
            UPdateText.Text = i;
            UPdateText.IsEnabled = true;
            await DongHua3();
        }
    }
}
