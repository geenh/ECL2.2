﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Natsurainko.FluentCore.Extension.Windows.Service;

namespace ECL2._2.Content.SettingPages
{
    /// <summary>
    /// JavaSetting.xaml 的交互逻辑
    /// </summary>
    public partial class JavaSetting : Page
    {
        public JavaSetting()
        {

            InitializeComponent();
            ServicePointManager.DefaultConnectionLimit = 512;
            

            // 返回一个表，包含了从注册表中检索到的系统中 Java 安装的全部信息
            var javalist = JavaHelper.SearchJavaRuntime();
            javaCombo.ItemsSource = javalist;


            //List<JavaVersion> aa = tools.GetJavaPath();
            //for (int i = 0; i < aa.Count; i++)
            //{
            //    javaCombo.Items.Add(aa[i].Path);
            //}
            if (javaCombo.Items.Count != 0)
            {
                javaCombo.SelectedItem = javaCombo.Items[0];
            }

        }

        public static void WriteFile(string Path, string Strings)
        {
            if (!System.IO.File.Exists(Path))
            {
                //Directory.CreateDirectory(Path);
                System.IO.FileStream f = System.IO.File.Create(Path);
                f.Close();
                f.Dispose();
            }
            System.IO.StreamWriter f2 = new System.IO.StreamWriter(Path, true, System.Text.Encoding.UTF8);
            f2.WriteLine(Strings);
            f2.Close();
            f2.Dispose();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            //Setting_Data.Ram= MemoryTextbox.Text;
            //Setting_Data.Java= javaCombo.Text;
            string path = "ECL2.2_Datas\\MinMemoryTextbox_Data.txt";
            File.Delete(path);
            WriteFile("ECL2.2_Datas\\MinMemoryTextbox_Data.txt", MinMemoryTextbox.Text);

            string path3 = "ECL2.2_Datas\\MaxMemoryTextbox_Data.txt";
            File.Delete(path3);
            WriteFile("ECL2.2_Datas\\MaxMemoryTextbox_Data.txt", MaxMemoryTextbox.Text);

            string path2 = @"ECL2.2_Datas\javaCombo_Data.txt";
            File.Delete(path2);
            WriteFile("ECL2.2_Datas\\javaCombo_Data.txt", javaCombo.Text);

            string path4 = "ECL2.2_Datas\\Width_Data.txt";
            File.Delete(path4);
            WriteFile("ECL2.2_Datas\\Width_Data.txt", Width1.Text);

            string path5 = @"ECL2.2_Datas\Height_Data.txt";
            File.Delete(path5);
            WriteFile("ECL2.2_Datas\\Height_Data.txt", Height.Text);

            button1.IsEnabled = false;
            for (int i = 0; i < 75; i++)
            {

                var Mov = SaveLabel.Margin;
                Mov.Left -= 5;
                SaveLabel.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 75; i++)
            {

                var Mov = SaveLabel.Margin;
                Mov.Left += 5;
                SaveLabel.Margin = Mov;
                await Task.Delay(1);


            }
            button1.IsEnabled = true;
        
    }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Microsoft.Win32.OpenFileDialog dialog = new Microsoft.Win32.OpenFileDialog()
            //{
            //    Title = "选择Java",
            //    Filter = "Java应用程序(无窗口)|javaw.exe",
            //};
            //if (dialog.ShowDialog() == true)
            //{
            //    javaCombo.ItemsSource = dialog.FileName;
            //}

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
