﻿
using MinecraftLaunch.Modules.Installer;
using MinecraftLaunch.Modules.Models.Install;
using MinecraftLaunch.Modules.Toolkits;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ECL2._2.Content
{
    /// <summary>
    /// Download.xaml 的交互逻辑
    /// </summary>
    public partial class Download : Page
    {
        
        public Download()
        {
            InitializeComponent();
            if (Directory.Exists("ECL2.2_Datas"))
            {

            }
            else
            {
                DirectoryInfo directoryInfo = new DirectoryInfo("ECL2.2_Datas");
                directoryInfo.Create();
            }
            if (!File.Exists("ECL2.2_Datas\\DownloadVersion-Temp.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\DownloadVersion-Temp.txt");//创建文件
                fs.Close();

            }
            if (!File.Exists("ECL2.2_Datas\\AutoInstall-Temp.txt"))
            {

                FileStream fs = File.Create("ECL2.2_Datas\\AutoInstall-Temp.txt");//创建文件
                fs.Close();

            }
            IList<string> list = new List<string>();
            list.Add("仅安装游戏本体");
            list.Add("安装游戏本体和Forge");

            list.Add("安装游戏本体和Fabric");
            list.Add("安装游戏本体和Quilt(Beta)(仅1.14以上)");
            AutoInstaller.ItemsSource = list;
            AutoInstaller.SelectedIndex = 0;
            IList<string> list1 = new List<string>();
            list1.Add("全部版本");
            list1.Add("仅正式版");

            list1.Add("仅预览版");
            list1.Add("仅远古版");
            Type_ComboBox.ItemsSource = list1;
            Type_ComboBox.SelectedIndex = 0;
            Flushed_All();

        }
        public async Task Flushed_All()
        {
            List<GameCoreEmtity> coreEmtities = new();
            await Task.Run(async () =>
            {
                
                var res = (await GameCoreInstaller.GetGameCoresAsync()).Cores;
                res.ToList().ForEach(x =>
                {

                    coreEmtities.Add(x);

                });
            });

            DownloadList.ItemsSource = coreEmtities;
        }

        public static void WriteFile(string Path, string Strings)
        {
            if (!System.IO.File.Exists(Path))
            {
                //Directory.CreateDirectory(Path);
                System.IO.FileStream f = System.IO.File.Create(Path);
                f.Close();
                f.Dispose();
            }
            System.IO.StreamWriter f2 = new System.IO.StreamWriter(Path, true, System.Text.Encoding.UTF8);
            f2.WriteLine(Strings);
            f2.Close();
            f2.Dispose();
        }
        public async Task DongHua1()
        {
            var Mov = VersionTextBoxE.Margin;
            
            VersionTextBoxE.Margin = Mov;
            for (int i = 0; i < 75; i++)
            {

                
                Mov.Left -= 5;
                VersionTextBoxE.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 75; i++)
            {

               
                Mov.Left += 5;
                VersionTextBoxE.Margin = Mov;
                await Task.Delay(1);


            }
            
        }
        public async Task DongHua2()
        {
            var Mov = JavaE.Margin;
            
            for (int i = 0; i < 80; i++)
            {

               
                Mov.Left -= 6.5;
                JavaE.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 80; i++)
            {

                
                Mov.Left += 6.5;
                JavaE.Margin = Mov;
                await Task.Delay(1);


            }
            
        }
        public async Task download()
        {
            if (!File.Exists("ECL2.2_Datas\\JavaCombo_Data.txt"))
            {
                
                await DongHua2();
            }
            else if (System.IO.File.ReadAllText("ECL2.2_Datas\\JavaCombo_Data.txt") == "")
            {
                await DongHua2();
            }
            else
            {
                if ((DownloadList.SelectedItem as GameCoreEmtity).Id == null)
                {

                    await DongHua1();
                }
                else if (AutoInstaller.SelectedIndex == 0)
                {


                    GameCoreToolkit toolkit = new(".minecraft");

                    var id = (DownloadList.SelectedItem as GameCoreEmtity).Id;
                    Label1.Content = "当前下载版本：" + id;

                    await Task.Run(async () =>
                    {
                        GameCoreInstaller coreInstaller = new(toolkit, id);



                        await Dispatcher.BeginInvoke(new Action(async delegate
                        {




                            await Task.Run(async () =>
                            {
                                var coreres = await coreInstaller.InstallAsync(async x =>
                                {
                                    await Dispatcher.BeginInvoke(new Action(async delegate
                                    {

                                        DownloadTB.Text += (x.Item2.ToString()) + "\n";
                                        progress.Content = Convert.ToDouble(x.Item1.ToString()) * 100 + "%";
                                        DownloadTB.ScrollToEnd();
                                    }));
                                });

                                //游戏资源补全安装模块
                                ResourceInstaller installer = new(coreres.GameCore);
                                await installer.DownloadAsync(async (x, c) =>
                                {
                                    await Dispatcher.BeginInvoke(new Action(async delegate
                                    {
                                        DownloadTB.Text += (x.ToString()) + "\n";
                                        progress.Content = Convert.ToDouble(c.ToString()) * 100 + "%";
                                        //在这里获取当前资源补全进度,利用c获取数字进度,x获取文字进度
                                    }));
                                    //安装的方法
                                });
                                
                            });
                            await Dispatcher.BeginInvoke(new Action(async delegate
                            {
                                Label1.Content = "当前无下载任务";
                            }));
                            MessageBox.Show("下载完成！");


                        }));
                    });
                   


                }
                else if (AutoInstaller.SelectedIndex == 1)
                {
                    var id = (DownloadList.SelectedItem as GameCoreEmtity).Id;
                    Label1.Content = "当前下载版本：" + id;
                    GameCoreToolkit toolkit = new(".minecraft");
                    var i = await ForgeInstaller.GetForgeBuildsOfVersionAsync(id);
                    string[] line = File.ReadAllLines(@"ECL2.2_Datas\javaCombo_Data.txt");
                    string JavaPaths = line[0];
                    
                    await Task.Run(async () =>
                    {
                        ForgeInstaller forgeInstaller = new(toolkit, i.First(), JavaPaths);

                        await forgeInstaller.InstallAsync(async x =>
                    {
                        await Dispatcher.BeginInvoke(new Action(async delegate
                        {
                            DownloadTB.Text += (x.Item2.ToString()) + "\n";
                            progress.Content = Convert.ToDouble(x.Item1.ToString()) * 100 + "%";
                            DownloadTB.ScrollToEnd();
                        }));
                       

                    });
                        await Dispatcher.BeginInvoke(new Action(async delegate
                        {
                            Label1.Content = "当前无下载任务";
                        }));
                        MessageBox.Show("下载完成！");

                    });


                }
                else if (AutoInstaller.SelectedIndex == 2)
                {
                    var id = (DownloadList.SelectedItem as GameCoreEmtity).Id;
                    Label1.Content = "当前下载版本：" + id;
                    GameCoreToolkit toolkit = new(".minecraft");
                    var i = await FabricInstaller.GetFabricBuildsByVersionAsync(id);
                   
                    await Task.Run(async () =>
                    {
                        FabricInstaller fabricInstaller = new(toolkit, i.First());

                        await fabricInstaller.InstallAsync(async x =>
                        {
                            await Dispatcher.BeginInvoke(new Action(async delegate
                            {
                                DownloadTB.Text += (x.Item2.ToString()) + "\n";
                                progress.Content = Convert.ToDouble(x.Item1.ToString()) * 100 + "%";
                                DownloadTB.ScrollToEnd();
                            }));

                        });
                        await Dispatcher.BeginInvoke(new Action(async delegate
                        {
                            Label1.Content = "当前无下载任务";
                        }));
                        MessageBox.Show("下载完成！");

                    });


                }
                else if (AutoInstaller.SelectedIndex == 3)
                    {
                    var id = (DownloadList.SelectedItem as GameCoreEmtity).Id;
                    Label1.Content = "当前下载版本：" + id;
                    GameCoreToolkit toolkit = new(".minecraft");
                    var i = await QuiltInstaller.GetQuiltBuildsByVersionAsync(id);
                    
                    string[] line = File.ReadAllLines(@"ECL2.2_Datas\javaCombo_Data.txt");
                    string JavaPaths = line[0];
                    await Task.Run(async () =>
                    {
                        QuiltInstaller quiltInstaller = new(toolkit, i.First());

                        await quiltInstaller.InstallAsync(async x =>
                        {
                            await Dispatcher.BeginInvoke(new Action(async delegate
                            {
                                DownloadTB.Text += (x.Item2.ToString()) + "\n";
                                progress.Content = Convert.ToDouble(x.Item1.ToString()) * 100 + "%";
                                DownloadTB.ScrollToEnd();
                            }));

                        });
                        await Dispatcher.BeginInvoke(new Action(async delegate
                        {
                            Label1.Content = "当前无下载任务";
                         }));
                    MessageBox.Show("下载完成！");

                    });



                }
            }
            }


        


        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            await download();
        }

        private async void Type_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Type_ComboBox.SelectedIndex == 0)
            {
                await Flushed_All();
            }
            else if (Type_ComboBox.SelectedIndex == 1)
            {
                List<GameCoreEmtity> coreEmtities = new();
                await Task.Run(async () =>
                {
                    
                    var res = (await GameCoreInstaller.GetGameCoresAsync()).Cores;
                    res.ToList().ForEach(x =>
                    {
                        if (x.Type is "release")
                            coreEmtities.Add(x);

                    });
                });
                DownloadList.ItemsSource = coreEmtities;
            }
            else if (Type_ComboBox.SelectedIndex == 2)
            {
                List<GameCoreEmtity> coreEmtities = new();
                await Task.Run(async () =>
                {
                    
                    var res = (await GameCoreInstaller.GetGameCoresAsync()).Cores;
                    res.ToList().ForEach(x =>
                    {
                        if (x.Type is "snapshot")
                            coreEmtities.Add(x);

                    });
                });
                DownloadList.ItemsSource = coreEmtities;
            }

            else if (Type_ComboBox.SelectedIndex == 3)
            {
                List<GameCoreEmtity> coreEmtities = new();
                await Task.Run(async () =>
                {
                    
                    var res = (await GameCoreInstaller.GetGameCoresAsync()).Cores;
                    res.ToList().ForEach(x =>
                    {
                        if (x.Type is "old_alpha")
                            coreEmtities.Add(x);

                    });
                });
                DownloadList.ItemsSource = coreEmtities;
            }

        }
    }
}
