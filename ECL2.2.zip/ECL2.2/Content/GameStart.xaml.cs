﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Threading;
using MinecraftLaunch.Launch;
using MinecraftLaunch.Modules.Enum;
using MinecraftLaunch.Modules.Models.Launch;
using MinecraftLaunch.Modules.Installer;
using MinecraftLaunch.Modules.Models.Auth;

using MinecraftLaunch.Modules.Toolkits;

using System.Diagnostics;
using Microsoft.VisualBasic;
using System.Windows.Media.Animation;

using System.Runtime.Serialization.Formatters;
using MinecaftOAuth;
using MicrosoftAuthenticator = MinecaftOAuth.MicrosoftAuthenticator;
using ECL2._2.Content.UserPages;

namespace ECL2._2.Content
{
    /// <summary>
    /// GameStart.xaml 的交互逻辑
    /// </summary>
    public partial class GameStart : Page
    {
        private string rootPath=".minecraft";
        Content.UserPages.Lixian Lixian = new Content.UserPages.Lixian();
        Content.UserPages.WeiRuan WeiRuan = new Content.UserPages.WeiRuan();
       
        public int LoginMode;
        public GameStart()
            {
                InitializeComponent();
          
            StartGameButton.Content = "启动";
            ContentControl1.Content = new Frame
            {
                Content = Lixian
            };
            LoginMode = 0;

            


        }
        public static void WriteFile(string Path, string Strings)
        {
            if (!System.IO.File.Exists(Path))
            {
                //Directory.CreateDirectory(Path);
                System.IO.FileStream f = System.IO.File.Create(Path);
                f.Close();
                f.Dispose();
            }
            System.IO.StreamWriter f2 = new System.IO.StreamWriter(Path, true, System.Text.Encoding.UTF8);
            f2.WriteLine(Strings);
            f2.Close();
            f2.Dispose();
        }
        public static LaunchConfig LaunchConfig { get; } = new LaunchConfig();
        public Account UserInfo { get; private set; }
        public async ValueTask Login()
        {
            FileStream fs = File.Create("ECL2.2_Datas\\Usercode_Temp.txt");//创建文件
            fs.Close();
            var id = System.IO.File.ReadAllText("ECL2.2_Datas\\ClientToken_Data.txt");
            var V = MessageBox.Show("确定开始验证您的账户", "验证", MessageBoxButton.OKCancel);
            MicrosoftAuthenticator microsoftAuthenticator = new(MinecaftOAuth.Module.Enum.AuthType.Access)
            {
                ClientId = "ed0e15b9-fa1e-489b-b83d-7a66ff149abd"
            };
            var code = await microsoftAuthenticator.GetDeviceInfo();
            MessageBox.Show("你的一次性访问代码在微软登录框中，点击确定开始验证账户");
            string path = "ECL2.2_Datas\\Usercode_Temp.txt";
            File.Delete(path);
            WriteFile("ECL2.2_Datas\\Usercode_Temp.txt", code.UserCode);
            WeiRuan.UUID.Content = "你的一次性访问代码是：" + code.UserCode;
            Debug.WriteLine("Link:{0} - Code:{1}", code.VerificationUrl, code.UserCode);
            if (V == MessageBoxResult.OK)
            {
                Process.Start(new ProcessStartInfo(code.VerificationUrl)
                {
                    UseShellExecute = true,
                    Verb = "open"
                });
            }
            try
            {
                var token = await microsoftAuthenticator.GetTokenResponse(code);
                var user = await microsoftAuthenticator.AuthAsync(x =>
                {
                    Debug.WriteLine(x);
                });
                UserInfo = user;
                WeiRuan.WelcomeID.Content = "欢迎回来," + user.Name;
                WeiRuan.UUID.Content = "登录完成!";
                File.Delete(path);
            }
            
            catch
            {
                WeiRuan.UUID.Content = "登录失败!";
                MessageBox.Show("登录失败，请确保已购买Minecraft");
                File.Delete(path);
            }
}
        public async Task DongHua1()
        {
            for (int i = 0; i < 75; i++)
            {

                var Mov = VersionE.Margin;
                Mov.Left -= 5;
                VersionE.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 75; i++)
            {

                var Mov = VersionE.Margin;
                Mov.Left += 5;
                VersionE.Margin = Mov;
                await Task.Delay(1);


            }


            

            }
        public async Task DongHua3()
        {
            for (int i = 0; i < 75; i++)
            {

                var Mov = UserE.Margin;
                Mov.Left -= 5;
                UserE.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 75; i++)
            {

                var Mov = UserE.Margin;
                Mov.Left += 5;
                UserE.Margin = Mov;
                await Task.Delay(1);


            }
        }
            public async Task DongHua2()
        {
            for (int i = 0; i < 75; i++)
            {

                var Mov = JavaE.Margin;
                Mov.Left -= 5;
                JavaE.Margin = Mov;
                await Task.Delay(1);


            }
            await Task.Delay(1000);
            for (int i = 0; i < 75; i++)
            {

                var Mov = JavaE.Margin;
                Mov.Left += 5;
                JavaE.Margin = Mov;
                await Task.Delay(1);


            }

        }
        public async ValueTask Start()
            {

            
            GameCoreToolkit toolkit = new(".minecraft");
            if (versionCombo.Text == "")
            {
                await DongHua1();
            }
            else if(!File.Exists("ECL2.2_Datas\\JavaCombo_Data.txt"))
            {
                await DongHua2();
            }
            else if((File.ReadAllText("ECL2.2_Datas\\JavaCombo_Data.txt"))=="")
            {
                await DongHua2();
            }
            else if(Lixian.IdTextbox.Text=="")
            {
                await DongHua3();
            }
            else 
            {
                string id = Lixian.IdTextbox.Text;
                string[] line1 = File.ReadAllLines(@"ECL2.2_Datas\Width_Data.txt");
                int Width = Convert.ToInt32(line1[0]);
                string[] line2 = File.ReadAllLines(@"ECL2.2_Datas\Height_Data.txt");
                int Height = Convert.ToInt32(line2[0]);
                int MinMemory = Convert.ToInt32(System.IO.File.ReadAllText("ECL2.2_Datas\\MinMemoryTextbox_Data.txt"));
                int MaxMemory = Convert.ToInt32(System.IO.File.ReadAllText("ECL2.2_Datas\\MaxMemoryTextbox_Data.txt"));
                string[] line = File.ReadAllLines(@"ECL2.2_Datas\JavaCombo_Data.txt");
                string Java = line[0];

                if (LoginMode == 1)
                {
                    await Login();
                    try
                    {

                        var launchConfig = new LaunchConfig()
                        {

                            Account = UserInfo,
                            GameWindowConfig = new GameWindowConfig()
                            {
                                Width = Width,
                                Height = Height,
                                IsFullscreen = false
                            },
                            JvmConfig = new JvmConfig(Java)
                            {
                                MaxMemory = MaxMemory,
                                MinMemory = MinMemory,
                            },
                            NativesFolder = null,
                            
                        };

                        //启动部分
                        JavaClientLauncher jcl = new(launchConfig, toolkit);
                        //启动！！
                        var Gameid = versionCombo.Text;
                        await Task.Run(async () =>
                        {
                            using var res = await jcl.LaunchTaskAsync(Gameid);

                            if (res.State is LaunchState.Succeess)
                            {
                                //启动成功的情况下会执行的代码块
                                MessageBox.Show("启动成功");
                            }
                            else
                            {
                                //启动失败的情况下会执行的代码块
                                MessageBox.Show("启动失败");
                                MessageBox.Show(res.Exception.ToString(), "详细异常信息：");
                            }
                        });
                    }
                    catch
                    {
                        MessageBox.Show("启动终止");
                    }
                }
                else if (LoginMode == 0)
                {

                    
                    var launchConfig = new LaunchConfig()
                    {

                        Account = new OfflineAccount(id, Guid.NewGuid().ToString(), Guid.NewGuid().ToString()),
                        GameWindowConfig = new GameWindowConfig()
                        {
                            Width = Width,
                            Height = Height,
                            IsFullscreen = false
                        },
                        JvmConfig = new JvmConfig(Java)
                        {
                            MaxMemory = MaxMemory,
                            MinMemory = MinMemory,
                        },
                       
                        NativesFolder = null,
                        
                    };

                    //启动部分
                    JavaClientLauncher jcl = new(launchConfig, toolkit);
                    //启动！！
                    var Gameid = versionCombo.Text;
                    await Task.Run(async () =>
                    {
                        using var res = await jcl.LaunchTaskAsync(Gameid);
                   
                    if (res.State is LaunchState.Succeess)
                    {
                        //启动成功的情况下会执行的代码块
                        MessageBox.Show("启动成功");
                    }
                    else
                    {
                        //启动失败的情况下会执行的代码块
                        MessageBox.Show("启动失败");
                          MessageBox.Show( res.Exception.ToString(), "详细异常信息：");
                    }
                    });
                }
                else
                {
                    MessageBox.Show("未选择启动模式");
                }
            }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
         {

            StartGameButton.Content = "启动中";
            StartGameButton.IsEnabled=false;
            await Start();
            StartGameButton.IsEnabled = true;
            StartGameButton.Content = "启动";
            
        }
        
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ContentControl1.Content = new Frame
            {
                Content = Lixian
            };
            LoginMode = 0;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ContentControl1.Content = new Frame
            {
                Content = WeiRuan
            };
            LoginMode = 1;
        }
    }
    }

